#!/usr/bin/env bash
# NTK Run Code - trinh khoi dong (tao boi Nong Tuan Kiet)
# Tu khoi dong may chu cuc bo de moi engine chay day du, roi mo cua so app.
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/app"
URL=""
SRV_PID=""

cleanup() { [ -n "$SRV_PID" ] && kill "$SRV_PID" 2>/dev/null; }
trap cleanup EXIT INT TERM

if command -v python3 >/dev/null 2>&1; then
  for p in 8765 8766 8767 8768 8769 8770; do
    python3 -m http.server "$p" --bind 127.0.0.1 --directory "$APP" >/dev/null 2>&1 &
    SRV_PID=$!
    sleep 0.8
    if python3 -c "import socket,sys; s=socket.socket(); sys.exit(0 if s.connect_ex(('127.0.0.1',$p))==0 else 1)" 2>/dev/null; then
      URL="http://127.0.0.1:$p/index.html"
      break
    fi
    kill "$SRV_PID" 2>/dev/null; SRV_PID=""
  done
fi
[ -z "$URL" ] && URL="file://$APP/index.html"
echo "NTK Run Code dang mo: $URL"

if [ "$(uname)" = "Darwin" ]; then
  for app in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" "/Applications/Chromium.app/Contents/MacOS/Chromium"; do
    if [ -x "$app" ]; then "$app" --app="$URL" --no-first-run; exit 0; fi
  done
  open "$URL"
else
  for b in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge; do
    if command -v "$b" >/dev/null 2>&1; then "$b" --app="$URL" --no-first-run; exit 0; fi
  done
  xdg-open "$URL" 2>/dev/null || sensible-browser "$URL" 2>/dev/null
fi
